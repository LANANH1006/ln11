package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Hướng dẫn dùng nhanh (cuộn bằng lăn chuột hoặc kéo). */
public class GuideScreen extends Screen {
    final Screen parent;
    double scroll;
    final List<String> lines = new ArrayList<>();

    static final String TEXT = String.join("\n",
        "§dLAN ANH CLIENT - HƯỚNG DẪN NHANH",
        "§7Chạm trái module = bật/tắt, chạm phải = cài đặt. Màn hình chính: Mods -> lan anh client.",
        "",
        "§eĐÀO HẦM THẲNG (TunnelDig - WORLD)",
        "§fĐứng đầu hầm, nhìn hướng muốn đào, bật module. Chuột phải để chỉnh:",
        "§f- Cúp thường: hầm 1x2, đào từng block.",
        "§f- Amethyst 3x3: đứng GIỮA, đào mặt 3x3 phía trước (cúp amethyst phá 9 khối, ô sót mod đào nốt).",
        "§f- Hướng: Theo nhìn / Bắc / Nam / Đông / Tây / Xuống (bậc thang).",
        "§f- Vá sàn: sàn hở thì cúi xuống đặt 1 block thường. Né lava: gặp lava thì dừng.",
        "",
        "§eTÌM CHỖ XÂY BASE KHÔNG HANG (BaseFinder - WORLD)",
        "§fChuột phải -> bật 'Mở bảng nhập X Z' -> nhập X Z, Y xây, kích thước, xa hang -> TÌM.",
        "§fChỉ tính hang từ deepslate (Y <= 'Hang từ Y') trở xuống. Kết quả: 4 trụ sáng ở 4 góc khu xây.",
        "§7Chỉ quét được chunk đã tải: đứng gần tọa độ, render distance >= 16.",
        "",
        "§eFREECAM CHỌN VÙNG ĐÀO (FreeDig - WORLD)",
        "§fBật module: camera bay tự do (WASD, Space lên, Shift xuống, Ctrl nhanh).",
        "§fBay tới góc TRÊN, ngắm block, bấm G. Bay xuống góc DƯỚI đối diện, bấm G. Bot tự đào cả vùng.",
        "§fBấm G khi đang đào = dừng. Đổi phím G trong Điều khiển.",
        "",
        "§eDÒ CĂN CỨ",
        "§fSusESP (đã bỏ Trail Ruins), SpawnerESP (ẩn lồng quái tự nhiên), HoleESP, Lightfinder, ChunkFinder.",
        "",
        "§eÂM BÀN PHÍM (KeySound)",
        "§f7 bộ Cherry MX. 'Toàn game': Giao diện = mọi tiếng menu/nút/cài đặt; Mọi tiếng = mọi thứ trong Minecraft (trừ nhạc).",
        "",
        "§eDỊCH CHAT (Translate)",
        "§fGõ tiếng Việt -> tự dịch sang tiếng Anh khi gửi. Chat người khác đổi thẳng sang tiếng Việt.",
        "",
        "§eMENU",
        "§fModule 'Giao diện': nền Tối/Màu/Gradient/Ảnh (config/lananh-bg.png), độ tối, khung giữa, Trong suốt %.",
        "",
        "§7Esc để đóng.");

    public GuideScreen(Screen parent) { super(Text.literal("Hướng dẫn")); this.parent = parent; }

    @Override protected void init() {
        lines.clear();
        int w = Math.min(width - 30, 400);
        for (String raw : TEXT.split("\n", -1)) {
            if (raw.isEmpty()) { lines.add(""); continue; }
            String prefix = raw.startsWith("§") && raw.length() > 2 ? raw.substring(0, 2) : "";
            for (var t : textRenderer.wrapLines(Text.literal(raw), w)) {
                StringBuilder sb = new StringBuilder(); t.accept((i, st, cp) -> { sb.appendCodePoint(cp); return true; });
                lines.add(prefix + sb.toString().replaceFirst("^§.", ""));
            }
        }
    }

    int maxScroll() { return Math.max(0, lines.size() * 11 - (height - 40)); }

    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll = Math.max(0, Math.min(maxScroll(), scroll - v * 22)); return true; }
    @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) { scroll = Math.max(0, Math.min(maxScroll(), scroll - dy)); return true; }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        MenuBg.draw(ctx, width, height, width / 2 - 205, 410);
        int x = width / 2 - 200;
        ctx.enableScissor(0, 20, width, height - 18);
        int y = 24 - (int) scroll;
        for (String l : lines) { ctx.drawTextWithShadow(textRenderer, l, x, y, 0xFFFFFFFF); y += 11; }
        ctx.disableScissor();
        ctx.drawCenteredTextWithShadow(textRenderer, "§7Lăn / kéo để cuộn - Esc đóng", width / 2, height - 12, 0xFFAAAAAA);
    }

    @Override public void close() { MinecraftClient.getInstance().setScreen(parent); }
}
