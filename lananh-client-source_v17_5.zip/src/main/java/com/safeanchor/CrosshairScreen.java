package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/** Vẽ tâm ngắm riêng: chuột trái (hoặc chạm) = tô ô, chuột phải = xóa ô. Có mẫu sẵn. */
public class CrosshairScreen extends Screen {
    final Screen parent;
    int cell = 10, gx, gy;

    public CrosshairScreen(Screen parent) { super(Text.literal("Tâm tự vẽ")); this.parent = parent; }

    @Override protected void init() {
        cell = Math.max(4, Math.min(12, (height - 150) / CrossPix.N));
        gx = width / 2 - CrossPix.N * cell / 2;
        gy = 30;
        int by = gy + CrossPix.N * cell + 6, x0 = width / 2 - 156;
        put(Pages.toggle("Dùng tâm này", () -> Config.I.crossCustom, v -> Config.I.crossCustom = v).get(), x0, by);
        put(Pages.button("Màu tâm", () -> MinecraftClient.getInstance().setScreen(new ColorScreen("tâm ngắm", this, () -> Config.I.crossDrawColor, v -> Config.I.crossDrawColor = v))).get(), x0 + 104, by);
        put(Pages.cycle("Cỡ", new String[]{"x1", "x2", "x3", "x4", "x5", "x6"}, () -> Math.max(0, Config.I.crossScale - 1), v -> Config.I.crossScale = v + 1).get(), x0 + 208, by);
        by += 22;
        put(Pages.button("Mẫu dấu +", () -> { Config.I.crossPix = CrossPix.plus(); }).get(), x0, by);
        put(Pages.button("Mẫu chấm", () -> { Config.I.crossPix = CrossPix.dot(); }).get(), x0 + 104, by);
        put(Pages.button("Mẫu vòng", () -> { Config.I.crossPix = CrossPix.ring(); }).get(), x0 + 208, by);
        by += 22;
        put(Pages.button("Xóa hết", () -> { Config.I.crossPix = CrossPix.blank(); }).get(), x0, by);
        put(Pages.button("Xong", this::close).get(), x0 + 104, by);
    }

    void put(ClickableWidget w, int x, int y) { w.setWidth(100); w.setX(x); w.setY(y); addDrawableChild(w); }

    @Override public void close() { Config.save(); MinecraftClient.getInstance().setScreen(parent); }
    @Override public void removed() { Config.save(); }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Vẽ tâm: chuột trái = tô • chuột phải = xóa"), width / 2, 10, 0xFFB388FF);
        int col = 0xFF000000 | Config.I.crossDrawColor;
        for (int y = 0; y < CrossPix.N; y++) for (int x = 0; x < CrossPix.N; x++) {
            int x0 = gx + x * cell, y0 = gy + y * cell;
            boolean on = CrossPix.on(Config.I.crossPix, x, y);
            boolean mid = x == 7 && y == 7;
            ctx.fill(x0, y0, x0 + cell - 1, y0 + cell - 1, on ? col : mid ? 0x60FF69B4 : 0x50FFFFFF);
        }
        // xem trước kích thước thật
        int sc = Math.max(1, Math.min(6, Config.I.crossScale)), pw = CrossPix.N * sc, ox = width - pw - 8, oy = 8;
        ctx.fill(ox - 2, oy - 2, ox + pw + 2, oy + pw + 2, 0x90000000);
        for (int y = 0; y < CrossPix.N; y++) for (int x = 0; x < CrossPix.N; x++)
            if (CrossPix.on(Config.I.crossPix, x, y)) ctx.fill(ox + x * sc, oy + y * sc, ox + (x + 1) * sc, oy + (y + 1) * sc, col);
    }

    void paint(double mx, double my, boolean v) {
        int x = (int) Math.floor((mx - gx) / cell), y = (int) Math.floor((my - gy) / cell);
        if (x < 0 || y < 0 || x >= CrossPix.N || y >= CrossPix.N) return;
        Config.I.crossPix = CrossPix.with(Config.I.crossPix, x, y, v);
    }
    boolean inGrid(double x, double y) { return x >= gx && y >= gy && x < gx + CrossPix.N * cell && y < gy + CrossPix.N * cell; }

    @Override public boolean mouseClicked(double x, double y, int b) {
        if (inGrid(x, y) && (b == 0 || b == 1)) { paint(x, y, b == 0); return true; }
        return super.mouseClicked(x, y, b);
    }
    @Override public boolean mouseDragged(double x, double y, int b, double dx, double dy) {
        if (inGrid(x, y) && (b == 0 || b == 1)) { paint(x, y, b == 0); return true; }
        return super.mouseDragged(x, y, b, dx, dy);
    }
}
