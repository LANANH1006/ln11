package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Danh sách module có "Cài đặt module" (chuột phải vào module): phím tắt riêng, độ mờ, giới hạn Y, bộ lọc block... */
public class Mods {
    public static class Cfg {
        public int key = -1;                 // phím tắt (mã GLFW), -1 = chưa gán
        public int alpha = 60;               // độ đậm khung (5-200)
        public int minY = -64, maxY = 320;   // giới hạn độ cao quét
        public int range = 48;               // tầm quét (block)
        public int color = 0xFF4040, color2 = 0xFFD040;
        public List<String> off = new ArrayList<>();   // loại block đang TẮT quét
    }

    /** flags: a = alpha, y = Min/Max Y, r = tầm, c = màu, f = bộ lọc block, 2 = màu thứ hai */
    public record Mod(String id, String name, BooleanSupplier get, Consumer<Boolean> set, String flags) {}

    public static final List<Mod> ALL = new ArrayList<>();
    static final Map<String, Boolean> down = new HashMap<>();

    static Config c() { return Config.I; }
    static void add(String id, String name, BooleanSupplier g, Consumer<Boolean> s, String flags) { ALL.add(new Mod(id, name, g, s, flags)); }

    static {
        add("sus", "Sus ESP (block khả nghi dưới lòng đất)", () -> c().susBase, v -> c().susBase = v, "ayrcf");
        add("spawner", "Spawner ESP (lồng spawner)", () -> c().spawnerEsp, v -> c().spawnerEsp = v, "arc");
        add("storage", "Storage ESP (rương / shulker / thùng)", () -> c().espStorage, v -> c().espStorage = v, "");
        add("hole", "Hole ESP (hố an toàn: obsidian / bedrock)", () -> c().holeEsp, v -> c().holeEsp = v, "ayrc2");
        add("light", "Lightfinder (nguồn sáng lạ: đuốc, đèn...)", () -> c().lightEsp, v -> c().lightEsp = v, "ayrc");
        add("chunk", "Chunk Finder v2 (chunk có người ở)", () -> c().susOn, v -> c().susOn = v, "y");
        add("espPlayers", "ESP người chơi", () -> c().espPlayers, v -> c().espPlayers = v, "");
        add("blocks", "ESP Block (quặng, block tùy chọn)", () -> c().espBlocks, v -> c().espBlocks = v, "");
        add("radar", "Radar", () -> c().radarOn, v -> c().radarOn = v, "");
        add("trail", "Trail", () -> c().trailOn, v -> c().trailOn = v, "");
        add("trig", "Triggerbot", () -> c().trigOn, v -> c().trigOn = v, "");
        add("shield", "Anchor Shield", () -> c().anchorShield, v -> c().anchorShield = v, "");
    }

    public static Mod find(String id) { for (Mod m : ALL) if (m.id().equals(id)) return m; return null; }

    public static Cfg cfg(String id) { return Config.I.mods.computeIfAbsent(id, Mods::def); }

    static Cfg def(String id) {
        Cfg c = new Cfg();
        switch (id) {
            case "sus" -> { c.alpha = 55; c.minY = -64; c.maxY = 8; c.color = 0xFF4040; c.range = 48; c.off.add("cobble"); c.off.add("rails"); }
            case "spawner" -> { c.alpha = 80; c.color = 0xB040FF; c.range = 64; }
            case "light" -> { c.alpha = 60; c.minY = -64; c.maxY = 40; c.color = 0xFFE040; c.range = 48; }
            case "hole" -> { c.alpha = 90; c.color = 0x40FF80; c.color2 = 0xFFD040; c.range = 8; }
            default -> {}
        }
        return c;
    }

    /** Phím tắt riêng của từng module (không cần mở GUI). */
    public static void tick(MinecraftClient mc) {
        if (mc.getWindow() == null) return;
        long h = mc.getWindow().getHandle();
        for (Mod m : ALL) {
            int k = cfg(m.id()).key;
            if (k < 32 || k > 348) { down.put(m.id(), false); continue; }
            boolean now = mc.currentScreen == null && GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
            boolean was = down.getOrDefault(m.id(), false);
            down.put(m.id(), now);
            if (now && !was) {
                boolean v = !m.get().getAsBoolean();
                m.set().accept(v); Config.save();
                Util.msg(m.name() + ": " + (v ? "§aBẬT" : "§cTẮT"));
            }
        }
    }
}
