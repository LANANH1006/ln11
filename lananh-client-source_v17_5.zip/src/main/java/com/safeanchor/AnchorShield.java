package com.safeanchor;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Anchor Shield: bạn tự đặt anchor, tự nạp 1-4 glowstone, rồi bấm nổ.
 * Đúng lúc bạn bấm nổ, client đặt NGAY 1 block chắn ở phía mình (obsidian, hết thì glowstone) trước khi gói tin nổ được gửi,
 * nên server xử lý: đặt block -> nổ. Block chắn chỉ chắn tia nổ từ anchor tới BẠN; nếu ô đó cũng chắn tia tới đối thủ
 * hoặc nằm đè lên đối thủ thì KHÔNG đặt (không bao giờ bảo vệ đối thủ).
 */
public class AnchorShield {
    static long lastTick = -100;

    /** Gọi từ UseBlockCallback (trước khi gói tin bấm anchor được gửi). Chỉ đặt block, không chặn thao tác của bạn. */
    public static void onUse(PlayerEntity pl, World w, Hand hand, BlockPos anchor) {
        Config c = Config.I;
        if (!c.anchorShield || !c.enabled || Util.bot || !w.isClient) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || pl != mc.player) return;
        if (w.getTime() - lastTick < 6) return;                                   // main hand + off hand: chỉ làm 1 lần
        BlockState st = w.getBlockState(anchor);
        if (!st.isOf(Blocks.RESPAWN_ANCHOR) || w.getRegistryKey() == World.NETHER) return;   // ở Nether anchor không nổ
        if (!willExplode(mc.player, hand, st.get(Properties.CHARGES))) return;
        lastTick = w.getTime();
        shield(mc, anchor);
    }

    /** Lần bấm này có làm anchor nổ không (có điện tích, không phải đang nạp, không ngồi shift cầm đồ). */
    static boolean willExplode(ClientPlayerEntity p, Hand hand, int charges) {
        if (charges < 1) return false;
        ItemStack main = p.getMainHandStack(), off = p.getOffHandStack();
        if (p.isSneaking() && !(main.isEmpty() && off.isEmpty())) return false;
        boolean mainG = main.isOf(Items.GLOWSTONE), offG = off.isOf(Items.GLOWSTONE);
        if (hand == Hand.MAIN_HAND) {
            if (mainG && charges < 4) return false;            // đang nạp thêm
            if (!mainG && offG && charges < 4) return false;   // tay chính bỏ qua, tay phụ sẽ nạp
        } else if (offG && charges < 4) return false;
        return true;
    }

    static boolean has(Item it) { return Util.has(s -> s.isOf(it)); }

    static void shield(MinecraftClient mc, BlockPos anchor) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        Item mat = has(Items.OBSIDIAN) ? Items.OBSIDIAN : (c.anchorShieldGlow && has(Items.GLOWSTONE) ? Items.GLOWSTONE : null);
        if (mat == null) { Util.warn("Anchor Shield: không có obsidian / glowstone"); return; }
        BlockPos cell = pickCell(mc, anchor);
        if (cell == null) return;                                  // không có ô nào an toàn (sẽ chắn luôn đối thủ) -> không đặt
        int old = p.getInventory().selectedSlot;
        boolean ok = place(mc, cell, mat, anchor);
        p.getInventory().selectedSlot = old;                       // trả lại ô tay cũ để cú bấm nổ giữ nguyên
        if (ok && c.anchorShieldMsg) Util.msg("Anchor Shield: đã chắn bằng " + (mat == Items.OBSIDIAN ? "obsidian" : "glowstone"));
    }

    /** Chọn ô chắn: chắn tia anchor->mình, nhưng không chắn tia anchor->đối thủ và không đè lên ai. */
    static BlockPos pickCell(MinecraftClient mc, BlockPos anchor) {
        var p = mc.player; var w = mc.world;
        Vec3d a = Vec3d.ofCenter(anchor);
        Vec3d meEye = p.getEyePos(), meMid = p.getPos().add(0, p.getHeight() * 0.5, 0);
        List<PlayerEntity> foes = new ArrayList<>();
        for (PlayerEntity o : w.getPlayers()) {
            if (o == p || o.isSpectator() || !o.isAlive()) continue;
            if (o.squaredDistanceTo(a) > 20 * 20) continue;
            foes.add(o);
        }
        List<BlockPos> cand = new ArrayList<>();
        for (Direction d : Direction.values()) cand.add(anchor.offset(d));
        BlockPos feet = p.getBlockPos();
        for (Direction d : Direction.Type.HORIZONTAL) { cand.add(feet.offset(d)); cand.add(feet.up().offset(d)); }
        cand.add(feet.up(2));

        BlockPos best = null; double bd = 1e18;
        for (BlockPos q : cand) {
            if (!w.getBlockState(q).isReplaceable()) continue;
            Box qb = new Box(q);
            Vec3d qc = Vec3d.ofCenter(q);
            if (meEye.distanceTo(qc) > Config.I.reach) continue;
            boolean bad = qb.intersects(p.getBoundingBox());
            for (PlayerEntity o : foes) if (qb.intersects(o.getBoundingBox().expand(0.15))) bad = true;   // không đè lên đối thủ
            if (bad) continue;
            if (!w.getOtherEntities(null, qb, e -> e instanceof PlayerEntity).isEmpty()) continue;
            // phải chắn tia tới mình
            if (qb.raycast(a, meEye).isEmpty() && qb.raycast(a, meMid).isEmpty()) continue;
            // không được chắn tia tới đối thủ (đầu / giữa / chân)
            boolean protectsFoe = false;
            for (PlayerEntity o : foes) {
                Vec3d f0 = o.getPos().add(0, 0.1, 0), f1 = o.getPos().add(0, o.getHeight() * 0.5, 0), f2 = o.getEyePos();
                if (qb.raycast(a, f0).isPresent() || qb.raycast(a, f1).isPresent() || qb.raycast(a, f2).isPresent()) { protectsFoe = true; break; }
            }
            if (protectsFoe) continue;
            double d = qc.distanceTo(a);                                   // càng sát anchor càng chắn được nhiều tia
            if (d < bd) { bd = d; best = q; }
        }
        return best;
    }

    static boolean plain(net.minecraft.world.World w, BlockPos nb) {
        BlockState s = w.getBlockState(nb);
        if (s.isAir() || s.isReplaceable() || !s.getFluidState().isEmpty() || s.hasBlockEntity()) return false;
        if (!s.isFullCube(w, nb)) return false;
        return !(s.isOf(Blocks.RESPAWN_ANCHOR) || s.isOf(Blocks.CRAFTING_TABLE) || s.isOf(Blocks.NOTE_BLOCK));
    }

    /** Đặt block, tránh bấm vào mặt anchor (bấm anchor đã nạp sẽ nổ sớm). Hết cách thì ngồi shift (gói tin) rồi bấm vào anchor. */
    static boolean place(MinecraftClient mc, BlockPos cell, Item mat, BlockPos anchor) {
        var p = mc.player; var w = mc.world;
        Vec3d eye = p.getEyePos();
        for (Direction d : Direction.values()) {
            BlockPos nb = cell.offset(d);
            if (!plain(w, nb)) continue;
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(nb).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            if (eye.distanceTo(hit) > Config.I.reach) continue;
            if (!Util.selectItem(s -> s.isOf(mat))) return false;
            var r = Util.interact(p, Hand.MAIN_HAND, new net.minecraft.util.hit.BlockHitResult(hit, face, nb, false));
            if (r.isAccepted()) { p.swingHand(Hand.MAIN_HAND); return true; }
        }
        if (cell.getManhattanDistance(anchor) != 1) return false;
        Direction d = Direction.fromVector(cell.getX() - anchor.getX(), cell.getY() - anchor.getY(), cell.getZ() - anchor.getZ(), null);
        if (d == null) return false;
        if (!Util.selectItem(s -> s.isOf(mat))) return false;
        Util.sendSneak(true);
        boolean ok = Util.useOnBlock(anchor, d);
        Util.sendSneak(false);
        return ok;
    }
}
