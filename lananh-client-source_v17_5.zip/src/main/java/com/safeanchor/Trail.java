package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Vệt đuôi khi di chuyển: gần người đậm, xa dần nhạt; chuyển dần giữa 2 màu (hoặc cầu vồng). */
public class Trail {
    static final List<Vec3d> hist = new ArrayList<>();   // phần tử 0 = mới nhất

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.trailOn || mc.player == null) { hist.clear(); return; }
        Vec3d p = mc.player.getPos();
        if (hist.isEmpty() || hist.get(0).squaredDistanceTo(p) > 0.0004) hist.add(0, p);
        else if (hist.size() > 1) hist.remove(hist.size() - 1);      // đứng yên thì đuôi co dần
        while (hist.size() > Math.max(4, c.trailLen)) hist.remove(hist.size() - 1);
    }

    static int lerp(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Config c = Config.I;
        if (!c.trailOn || !c.enabled || mc.player == null || hist.size() < 2) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Vec3d cp = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(false);
        List<Vec3d> pts = new ArrayList<>();
        pts.add(mc.player.getLerpedPos(td));
        pts.addAll(hist);
        int n = pts.size();
        double h = c.trailHeight;
        double base = c.trailPos == 2 ? 1.8 : c.trailPos == 1 ? 0.9 - h / 2 : 0.0;   // trên đầu / giữa người / dưới chân

        Matrix4f m = ms.peek().getPositionMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int quads = 0;
        for (int i = 0; i < n - 1; i++) {
            Vec3d a = pts.get(i).subtract(cp), b = pts.get(i + 1).subtract(cp);
            if (a.lengthSquared() < 2.0) continue;                 // không vẽ sát camera
            double t0 = i / (double) (n - 1), t1 = (i + 1) / (double) (n - 1);
            int c0 = c.trailChroma ? Util.chroma(t0 * 0.5) : lerp(c.trailColor1, c.trailColor2, t0);
            int c1 = c.trailChroma ? Util.chroma(t1 * 0.5) : lerp(c.trailColor1, c.trailColor2, t1);
            int a0 = (int) (c.trailAlpha * (1 - t0)), a1 = (int) (c.trailAlpha * (1 - t1));
            Esp.v(bb, m, a.x, a.y + base, a.z, c0, a0);
            Esp.v(bb, m, a.x, a.y + base + h, a.z, c0, a0);
            Esp.v(bb, m, b.x, b.y + base + h, b.z, c1, a1);
            Esp.v(bb, m, b.x, b.y + base, b.z, c1, a1);
            quads++;
        }
        if (quads > 0) BufferRenderer.drawWithGlobalProgram(bb.end());
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }
}
